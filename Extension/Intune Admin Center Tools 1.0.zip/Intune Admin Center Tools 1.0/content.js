if (window.location.href.includes("intune.microsoft.com/#view/Microsoft_Intune_Devices/DeviceSettingsMenuBlade/")) {
  console.log("On Intune Device Settings page.");
}
